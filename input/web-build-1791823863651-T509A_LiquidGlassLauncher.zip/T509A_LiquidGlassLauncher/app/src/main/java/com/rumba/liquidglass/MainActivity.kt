package com.rumba.liquidglass

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class Page { HOME, APPS, CONTROL, SETTINGS }

private data class Wallpaper(val name: String, val top: Color, val bottom: Color, val glow: Color)

private val wallpapers = listOf(
    Wallpaper("Azul noche", Color(0xFF071526), Color(0xFF24476B), Color(0xFF9BCBFF)),
    Wallpaper("Grafito", Color(0xFF101116), Color(0xFF363B47), Color(0xFFD6E2F7)),
    Wallpaper("Océano", Color(0xFF052A3A), Color(0xFF12627A), Color(0xFF8CE4F5)),
    Wallpaper("Violeta", Color(0xFF17112D), Color(0xFF49386D), Color(0xFFCBB7FF))
)

private data class AppEntry(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        setContent { LiquidGlassApp() }
    }
}

@Composable
private fun LiquidGlassApp() {
    val context = LocalContext.current
    val pm = context.packageManager
    var page by remember { mutableStateOf(Page.HOME) }
    var wallpaperIndex by remember { mutableIntStateOf(0) }
    var showWeather by remember { mutableStateOf(true) }
    var boldClock by remember { mutableStateOf(true) }
    var search by remember { mutableStateOf("") }
    var wifiDemo by remember { mutableStateOf(true) }
    var bluetoothDemo by remember { mutableStateOf(false) }
    var focusDemo by remember { mutableStateOf(false) }
    var brightness by remember { mutableFloatStateOf(0.75f) }
    var clockText by remember { mutableStateOf("09:41") }
    var dateText by remember { mutableStateOf("LUNES, 12 DE OCTUBRE") }
    val wallpaper = wallpapers[wallpaperIndex]

    LaunchedEffect(Unit) {
        while (true) {
            val now = Date()
            clockText = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            dateText = SimpleDateFormat("EEEE, d 'de' MMMM", Locale("es", "AR"))
                .format(now).uppercase(Locale("es", "AR"))
            delay(15_000)
        }
    }

    val apps = remember {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .mapNotNull { ri ->
                val name = ri.loadLabel(pm)?.toString() ?: return@mapNotNull null
                val pkg = ri.activityInfo?.packageName ?: return@mapNotNull null
                if (pkg == context.packageName) null else AppEntry(name, pkg, ri.loadIcon(pm))
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    BackHandler(enabled = page != Page.HOME) { page = Page.HOME }

    MaterialTheme(colorScheme = darkColorScheme(
        background = wallpaper.top,
        surface = Color(0xCC192536),
        primary = Color(0xFF8CC8FF),
        onSurface = Color.White
    )) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(wallpaper.top, wallpaper.bottom)))
                .pointerInput(page) {
                    var drag = 0f
                    detectHorizontalDragGestures(
                        onHorizontalDrag = { _, amount -> drag += amount },
                        onDragEnd = {
                            if (page == Page.HOME && drag < -70) page = Page.APPS
                            if (page == Page.APPS && drag > 70) page = Page.HOME
                            drag = 0f
                        }
                    )
                }
        ) {
            AnimatedContent(
                targetState = page,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "page"
            ) { current ->
                when (current) {
                    Page.HOME -> HomePage(
                        clockText, dateText, wallpaper, showWeather, boldClock, apps,
                        onOpenApp = { launchApp(context, it.packageName) },
                        onApps = { page = Page.APPS },
                        onControl = { page = Page.CONTROL },
                        onSettings = { page = Page.SETTINGS }
                    )
                    Page.APPS -> AppsPage(
                        apps = apps,
                        search = search,
                        onSearch = { search = it },
                        onBack = { page = Page.HOME },
                        onOpenApp = { launchApp(context, it.packageName) }
                    )
                    Page.CONTROL -> ControlPage(
                        wifiDemo, { wifiDemo = it },
                        bluetoothDemo, { bluetoothDemo = it },
                        focusDemo, { focusDemo = it },
                        brightness, { brightness = it },
                        onBack = { page = Page.HOME }
                    )
                    Page.SETTINGS -> SettingsPage(
                        wallpaperIndex, { wallpaperIndex = it },
                        showWeather, { showWeather = it },
                        boldClock, { boldClock = it },
                        onBack = { page = Page.HOME }
                    )
                }
            }
            BottomDock(
                modifier = Modifier.align(Alignment.BottomCenter),
                onHome = { page = Page.HOME },
                onApps = { page = Page.APPS },
                onControl = { page = Page.CONTROL },
                onSettings = { page = Page.SETTINGS },
                onOpenApp = { entry -> launchApp(context, entry.packageName) },
                apps = apps
            )
        }
    }
}

private fun launchApp(context: android.content.Context, packageName: String) {
    val intent = context.packageManager.getLaunchIntentForPackage(packageName)
    if (intent != null) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }
}

@Composable
private fun HomePage(
    clock: String,
    date: String,
    wallpaper: Wallpaper,
    showWeather: Boolean,
    boldClock: Boolean,
    apps: List<AppEntry>,
    onOpenApp: (AppEntry) -> Unit,
    onApps: () -> Unit,
    onControl: () -> Unit,
    onSettings: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp)
            .padding(bottom = 100.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("TCL · LIQUID GLASS", color = Color.White.copy(alpha = .72f), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.5.sp)
                Text("Tu espacio", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            IconBubble(Icons.Default.Tune, "Centro de control", onControl)
        }

        Spacer(Modifier.height(16.dp))

        // Oversized translucent clock panel inspired by iOS lock-screen typography.
        Box(
            modifier = Modifier.fillMaxWidth()
                .shadow(22.dp, RoundedCornerShape(34.dp), ambientColor = wallpaper.glow.copy(alpha = .12f))
                .clip(RoundedCornerShape(34.dp))
                .background(Brush.verticalGradient(listOf(
                    Color.White.copy(alpha = .22f),
                    Color.White.copy(alpha = .075f),
                    wallpaper.glow.copy(alpha = .10f)
                )))
                .padding(horizontal = 8.dp, vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(date, color = Color.White.copy(alpha = .86f), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.1.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(0.dp))
                Text(
                    clock,
                    color = Color.White.copy(alpha = .96f),
                    fontSize = if (boldClock) 88.sp else 78.sp,
                    lineHeight = if (boldClock) 90.sp else 82.sp,
                    fontWeight = if (boldClock) FontWeight.Black else FontWeight.Light,
                    letterSpacing = (-5).sp,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
                Box(Modifier.padding(top = 2.dp).width(108.dp).height(2.dp).clip(CircleShape)
                    .background(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = .8f), Color.Transparent))))
                Text("LIQUID GLASS", modifier = Modifier.padding(top = 5.dp), color = Color.White.copy(alpha = .52f), fontSize = 9.sp, letterSpacing = 3.sp)
            }
        }

        if (showWeather) {
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                    .background(Color.White.copy(alpha = .12f))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Cloud, null, tint = Color.White, modifier = Modifier.size(32.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Buenos Aires", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text("Clima de ejemplo", color = Color.White.copy(alpha = .68f), fontSize = 11.sp)
                }
                Text("18°", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Light)
            }
        }

        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Aplicaciones", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text("Ver todas  ›", color = wallpaper.glow, fontSize = 12.sp, modifier = Modifier.clickable(onClick = onApps))
        }
        Spacer(Modifier.height(10.dp))
        val favoriteApps = apps.take(8)
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(15.dp)
        ) {
            items(favoriteApps, key = { it.packageName }) { app ->
                AppIcon(app, onClick = { onOpenApp(app) })
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            repeat(3) { i ->
                Box(Modifier.padding(horizontal = 3.dp).size(if (i == 0) 7.dp else 5.dp).clip(CircleShape)
                    .background(Color.White.copy(alpha = if (i == 0) .9f else .35f)))
            }
        }
    }
}

@Composable
private fun AppIcon(app: AppEntry, onClick: () -> Unit) {
    val context = LocalContext.current
    Column(
        modifier = Modifier.clickable(onClick = onClick).padding(2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        // Real installed app icon, displayed in an iOS-like rounded-square tile.
        Box(
            modifier = Modifier.size(54.dp).shadow(8.dp, RoundedCornerShape(16.dp))
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White.copy(alpha = .16f)),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.foundation.Image(
                painter = androidx.compose.ui.graphics.painter.BitmapPainter(
                    app.icon.toBitmapImage()
                ),
                contentDescription = app.label,
                modifier = Modifier.fillMaxSize()
            )
        }
        Text(app.label, color = Color.White, fontSize = 10.sp, maxLines = 1, textAlign = TextAlign.Center)
    }
}

private fun android.graphics.drawable.Drawable.toBitmapImage(): androidx.compose.ui.graphics.ImageBitmap {
    val bitmap = android.graphics.Bitmap.createBitmap(
        intrinsicWidth.coerceAtLeast(1), intrinsicHeight.coerceAtLeast(1), android.graphics.Bitmap.Config.ARGB_8888
    )
    val canvas = android.graphics.Canvas(bitmap)
    setBounds(0, 0, canvas.width, canvas.height)
    draw(canvas)
    return bitmap.asImageBitmap()
}

private fun android.graphics.Bitmap.asImageBitmap(): androidx.compose.ui.graphics.ImageBitmap =
    androidx.compose.ui.graphics.asImageBitmap(this)

@Composable
private fun IconBubble(icon: ImageVector, description: String, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = .15f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, description, tint = Color.White) }
}

@Composable
private fun BottomDock(
    modifier: Modifier,
    onHome: () -> Unit,
    onApps: () -> Unit,
    onControl: () -> Unit,
    onSettings: () -> Unit,
    onOpenApp: (AppEntry) -> Unit,
    apps: List<AppEntry>
) {
    Row(
        modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp)
            .navigationBarsPadding().shadow(18.dp, RoundedCornerShape(30.dp))
            .clip(RoundedCornerShape(30.dp))
            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = .23f), Color.White.copy(alpha = .12f))))
            .padding(horizontal = 8.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        DockButton(Icons.Default.Home, "Inicio", onHome)
        DockButton(Icons.Default.Apps, "Aplicaciones", onApps)
        DockButton(Icons.Default.Tune, "Controles", onControl)
        DockButton(Icons.Default.Settings, "Ajustes", onSettings)
        apps.firstOrNull()?.let { app -> DockButton(Icons.Default.Favorite, app.label, { onOpenApp(app) }) }
    }
}

@Composable
private fun DockButton(icon: ImageVector, label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(23.dp))
    }
}

@Composable
private fun AppsPage(
    apps: List<AppEntry>,
    search: String,
    onSearch: (String) -> Unit,
    onBack: () -> Unit,
    onOpenApp: (AppEntry) -> Unit
) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 18.dp).padding(bottom = 100.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBubble(Icons.Default.ArrowBack, "Volver", onBack)
            Spacer(Modifier.width(12.dp))
            Text("Biblioteca", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Buscar aplicaciones…", color = Color.White.copy(alpha = .55f)) },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = Color.White) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                focusedBorderColor = Color.White.copy(alpha = .6f),
                unfocusedBorderColor = Color.White.copy(alpha = .25f),
                cursorColor = Color.White
            )
        )
        Spacer(Modifier.height(12.dp))
        val filtered = apps.filter { it.label.contains(search, ignoreCase = true) }
        LazyVerticalGrid(columns = GridCells.Fixed(4), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            items(filtered, key = { it.packageName }) { AppIcon(it) { onOpenApp(it) } }
        }
    }
}

@Composable
private fun ControlPage(
    wifi: Boolean, setWifi: (Boolean) -> Unit,
    bluetooth: Boolean, setBluetooth: (Boolean) -> Unit,
    focus: Boolean, setFocus: (Boolean) -> Unit,
    brightness: Float, setBrightness: (Float) -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 18.dp).padding(bottom = 100.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBubble(Icons.Default.ArrowBack, "Volver", onBack)
            Spacer(Modifier.width(12.dp))
            Text("Centro de control", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ControlTile("Wi-Fi", Icons.Default.Wifi, wifi, { setWifi(!wifi) }, Modifier.weight(1f))
            ControlTile("Bluetooth", Icons.Default.Bluetooth, bluetooth, { setBluetooth(!bluetooth) }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ControlTile("Enfoque", Icons.Default.DoNotDisturbOn, focus, { setFocus(!focus) }, Modifier.weight(1f))
            ControlTile("Linterna", Icons.Default.FlashlightOn, false, { }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(18.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color.White.copy(alpha = .14f)).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.BrightnessHigh, null, tint = Color.White)
                Spacer(Modifier.width(10.dp))
                Text("Brillo visual del tema", color = Color.White, fontWeight = FontWeight.SemiBold)
            }
            Slider(value = brightness, onValueChange = setBrightness)
            Text("Estos controles son visuales; Wi-Fi y Bluetooth reales se administran en Ajustes de Android.", color = Color.White.copy(alpha = .65f), fontSize = 11.sp)
        }
    }
}

@Composable
private fun ControlTile(title: String, icon: ImageVector, enabled: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(if (enabled) Color(0xFF397CC5) else Color.White.copy(alpha = .13f))
            .clickable(onClick = onClick).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(28.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
        Text(if (enabled) "Activado" else "Desactivado", color = Color.White.copy(alpha = .72f), fontSize = 11.sp)
    }
}

@Composable
private fun SettingsPage(
    wallpaperIndex: Int,
    onWallpaper: (Int) -> Unit,
    showWeather: Boolean,
    onShowWeather: (Boolean) -> Unit,
    boldClock: Boolean,
    onBoldClock: (Boolean) -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 18.dp).padding(bottom = 100.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBubble(Icons.Default.ArrowBack, "Volver", onBack)
            Spacer(Modifier.width(12.dp))
            Text("Personalización", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(14.dp))
        Column(Modifier.clip(RoundedCornerShape(24.dp)).background(Color.White.copy(alpha = .13f)).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Reloj extra grande", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Números gruesos estilo Liquid Glass", color = Color.White.copy(alpha = .65f), fontSize = 11.sp)
                }
                Switch(checked = boldClock, onCheckedChange = onBoldClock)
            }
            HorizontalDivider(color = Color.White.copy(alpha = .18f))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Widget del clima", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Tarjeta informativa de ejemplo", color = Color.White.copy(alpha = .65f), fontSize = 11.sp)
                }
                Switch(checked = showWeather, onCheckedChange = onShowWeather)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Fondo de pantalla", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        wallpapers.forEachIndexed { index, wall ->
            Row(
                Modifier.fillMaxWidth().padding(bottom = 9.dp).clip(RoundedCornerShape(18.dp))
                    .background(if (index == wallpaperIndex) Color.White.copy(alpha = .20f) else Color.White.copy(alpha = .08f))
                    .clickable { onWallpaper(index) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Brush.verticalGradient(listOf(wall.top, wall.bottom))))
                Spacer(Modifier.width(12.dp))
                Text(wall.name, color = Color.White, modifier = Modifier.weight(1f))
                if (index == wallpaperIndex) Icon(Icons.Default.CheckCircle, null, tint = wall.glow)
            }
        }
    }
}
