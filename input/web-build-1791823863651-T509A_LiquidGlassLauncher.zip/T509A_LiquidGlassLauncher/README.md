# T509A Liquid Glass Launcher

Aplicación Android nativa en Kotlin + Jetpack Compose, preparada como punto de partida para TCL 505 T509A / Android 14.

## Qué incluye
- Launcher Android seleccionable como pantalla de inicio.
- Reloj dinámico de gran tamaño, con números gruesos y tarjeta translúcida inspirada en Liquid Glass.
- Biblioteca de aplicaciones instaladas con búsqueda y apertura.
- Dock inferior y navegación entre Inicio, Biblioteca, Centro de control y Personalización.
- Fondos degradados y opciones para ocultar el widget de clima y cambiar el peso del reloj.
- `minSdk 26`, `targetSdk 34`.

## Limitaciones importantes
- El widget del clima muestra texto de ejemplo; no consulta el clima real.
- Los controles de Wi-Fi/Bluetooth/enfoque son visuales y no cambian los ajustes del sistema.
- Esta app es un **launcher**, no reemplaza la pantalla de bloqueo segura de Android. Para evitar riesgos, no requiere root, bootloader desbloqueado ni cambios en particiones.
- Los iconos que aparecen son los iconos reales de las apps instaladas, dentro de contenedores redondeados; no son réplicas exactas de los iconos de Apple.
- El proyecto no incluye `gradlew` ni `gradle-wrapper.jar`; AndroidIDE/otro IDE Android puede generar/usar su propio Gradle. También puede abrirse desde Android Studio en una computadora.

## Compilar desde el propio celular
1. Descarga e instala un entorno de desarrollo Android de una fuente confiable que siga mantenido y sea compatible con tu Android. AndroidIDE es una opción conocida, pero su repositorio original está archivado y ya no se mantiene; verifica su estado actual antes de instalarlo.
2. Extrae el ZIP en una carpeta local, por ejemplo `Download/T509A_LiquidGlassLauncher`.
3. En el IDE, elige **Open existing project** y selecciona esa carpeta.
4. Deja que Gradle descargue las dependencias (la primera sincronización necesita conexión y almacenamiento libre).
5. Ejecuta la tarea `:app:assembleDebug` o el botón Build/Run del IDE.
6. El APK normalmente aparecerá en `app/build/outputs/apk/debug/app-debug.apk`.
7. Instala el APK. Si Android lo solicita, autoriza temporalmente a esa aplicación la instalación de apps desconocidas.
8. Pulsa Inicio y selecciona **Liquid Glass** como aplicación de inicio. Para volver atrás, ve a Ajustes > Aplicaciones > Aplicaciones predeterminadas > Aplicación de inicio y elige el launcher anterior (la ruta exacta puede variar).

## Versiones de herramientas del proyecto
- Android Gradle Plugin 8.6.1
- Kotlin 2.0.21
- Compose BOM 2024.09.03
- JDK 17
- compileSdk 35, targetSdk 34

Si el entorno móvil no puede resolver esas versiones, usa un IDE compatible con AGP 8.6.1/JDK 17 o ajusta las versiones en los archivos Gradle.

## Recuperación
No desinstales el launcher anterior ni cambies el firmware. Para revertir la interfaz, selecciona la aplicación de inicio original en Ajustes. No hay que desbloquear el bootloader.
